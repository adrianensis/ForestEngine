#############################
MD5 sample mesh and animation
#############################

INFORMATION & USAGE
===================
File includes *.blend source files and TGA format textures for MD5 animated mesh testing.
For extensive information and usage instructions visit http://www.katsbits.com/smforum/index.php?topic=178.0

 - bob_lamp_update.blend contain mesh and armature as would be prior to preparation for export.
 - bob_lamp_update_export contains triangulated mesh ready for export.

NOTES
=====
Included files are for use in **Blender 2.69** or above; opening files in older versions may result in errors dues to internal differences between Blender versions.
Files and media are provided "as is" without any warranties of functionality.

COPYRIGHT & DISTRIBUTION
========================
Copyright � 2014 KatsBits. All Rights Reserved.
For more information visit http://www.katsbits.com/ or email info@katsbits.com

For NON-COMMERCIAL USE ONLY. This file and/or its contents and/or associated materials may not be reproduced, duplicated, distributed or otherwise 'monetised' without prior consent.
Contact info@katsbits.com or visit http://copyright.katsbits.com/ for further details regarding this material and/or distribution/copyright.
